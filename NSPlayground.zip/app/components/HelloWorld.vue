<template>
    <Page class="page">
        <ActionBar title="Geolocation" class="action-bar" />
        <ScrollView>
            <StackLayout class="home-panel">
                <Image src="~/images/map-marker-icon.png" height="60" />
                <Button text="Start tracking" @tap="getLocation"
                    class="btn btn-primary" />

                <Label :text="'Latitude: ' + latitude" class="lbl" />
                <Label :text="'Longitude: ' + longitude" class="lbl" />
                <Label :text="'Altitude: '+altitude + 'm'" class="lbl" />
                <Label :text="'Speed: ' + speed + 'km/h'" class="lbl" />
            </StackLayout>
        </ScrollView>
    </Page>
</template>

<script>
    const geolocation = require("nativescript-geolocation");
    const {
        Accuracy
    } = require("tns-core-modules/ui/enums");

    export default {
        data() {
            return {
                latitude: "",
                longitude: "",
                speed: "",
                altitude: "",
                device: "gsm"
            };
        },
        methods: {
            getLocation() {
                geolocation
                    .getCurrentLocation({
                        desiredAccuracy: Accuracy.High,
                        maximumAge: 3000,
                        timeout: 3000
                    })
                    .then(res => {
                        this.latitude = res.latitude;
                        this.longitude = res.longitude;
                        this.speed = res.speed * 3.6;
                        this.altitude = res.altitude;
                    });
            }
        },
        mounted() {
            geolocation.enableLocationRequest();
        }
    };
</script>

<style scoped>
    .home-panel {
        vertical-align: center;
        font-size: 20;
        margin: 15;
    }

    .description-label {
        margin-bottom: 15;
    }
</style>